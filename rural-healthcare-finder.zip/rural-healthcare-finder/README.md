# Rural Healthcare Access Finder

Built for Smart India Hackathon — Agriculture, FoodTech & Rural Development.

Helps rural users find nearby health facilities, get simple symptom urgency guidance,
and check eligibility for government health schemes.

## User Flow
1. **Login** — enter name + phone number (stored locally in the browser, no password)
2. **Symptom Check** (Step 1) — select symptoms, type your own if not listed, or speak them
3. **Find Facility** (Step 2) — jumps straight to nearby facilities matching your urgency, shows doctor availability, plus your local ASHA worker's contact
4. **Health Schemes** (Step 3) — check eligibility, shown against your logged-in name

## Features
1. **Login** — simple phone-number based sign-in, gates Facility Finder and Schemes pages
2. **Symptom Triage** — checkbox + free-text + voice input, fuzzy substring matching so typed symptoms like "high fever" still match correctly, direct 108 emergency banner for urgent cases
3. **Facility Finder** — auto-filters to the facility type recommended by your symptom check, shows real-time doctor availability per facility, supports location/village/taluk search against real Mandya district data
4. **Scheme Eligibility** — checks which health schemes a user may qualify for
5. **ASHA Worker Connect** — shows the local ASHA (Accredited Social Health Activist) community health worker's contact for a searched village/taluk

## Setup

### Backend
```bash
cd backend
pip install -r requirements.txt
python app.py
```
Runs on http://127.0.0.1:5000

### Frontend
Just open `frontend/index.html` directly in a browser, or serve it with:
```bash
cd frontend
python -m http.server 8000
```
Then visit http://127.0.0.1:8000

**Important:** the backend must be running for the frontend to work — the pages call
`http://127.0.0.1:5000/api/...` under the hood (see `frontend/js/api.js`).

## Team Split Suggestion
- **Person 1 (Backend):** extend `backend/routes/` — add more symptoms to triage.py,
  add real district data to facilities.csv
- **Person 2 (Frontend):** polish `frontend/css/style.css`, add regional language toggle
- **Person 3 (Data/Content):** curate real facility + scheme data for your demo district,
  prep the pitch deck

## Ideas to Add If Time Permits
- Regional language toggle (Hindi/Kannada) for key screens
- Voice input for symptom checker (Web Speech API — no backend change needed)
- "Nearest facility" auto-suggestion on the triage result page (link triage.js result
  urgency to facility-finder.html with filter applied)
- Telemedicine mock button ("Consult a doctor now" → shows a demo booking screen)

## Notes for the Demo
- Sample data is centered on Shivamogga district, Karnataka — update facilities.csv
  and the fallback coordinates in `js/map.js` if you want a different region
- Symptom checker is explicitly NOT a diagnostic tool — keep that framing in your pitch
