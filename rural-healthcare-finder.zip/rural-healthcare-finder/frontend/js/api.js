// Base URL for the Flask backend. Change this if you deploy the backend elsewhere.
const API_BASE = "http://127.0.0.1:5000/api";

async function fetchNearbyFacilities(lat, lng) {
  const res = await fetch(`${API_BASE}/facilities?lat=${lat}&lng=${lng}`);
  if (!res.ok) throw new Error("Failed to fetch facilities");
  return res.json();
}

async function searchFacilitiesByName(query) {
  const res = await fetch(`${API_BASE}/facilities/search?q=${encodeURIComponent(query)}`);
  if (!res.ok) throw new Error("Failed to search facilities");
  return res.json();
}

async function findAshaWorker(query) {
  const res = await fetch(`${API_BASE}/asha-worker?q=${encodeURIComponent(query)}`);
  if (!res.ok) throw new Error("Failed to find ASHA worker");
  return res.json();
}

async function checkTriage(symptoms) {
  const res = await fetch(`${API_BASE}/triage`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ symptoms }),
  });
  if (!res.ok) throw new Error("Failed to check triage");
  return res.json();
}

async function checkSchemeEligibility(income, state) {
  const res = await fetch(`${API_BASE}/schemes`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ income, state }),
  });
  if (!res.ok) throw new Error("Failed to check schemes");
  return res.json();
}
