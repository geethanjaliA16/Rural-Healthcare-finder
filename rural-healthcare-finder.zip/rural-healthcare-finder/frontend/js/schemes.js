// Show who this eligibility check is for, using the logged-in user's details
const user = getCurrentUser();
if (user) {
  document.getElementById("checking-for").textContent = `Checking eligibility for ${user.name} (${user.phone})`;
}

document.getElementById("schemes-form").addEventListener("submit", async (e) => {
  e.preventDefault();

  const income = document.getElementById("income").value;
  const state = document.getElementById("state").value;
  const resultEl = document.getElementById("schemes-result");

  resultEl.classList.remove("hidden");
  resultEl.innerHTML = "<p>Checking eligibility...</p>";

  try {
    const data = await checkSchemeEligibility(income, state);

    if (data.count === 0) {
      resultEl.innerHTML = "<p>No matching schemes found for the details provided.</p>";
      return;
    }

    resultEl.innerHTML = `
      <h3>You may be eligible for ${data.count} scheme(s):</h3>
      ${data.eligible_schemes.map(s => `
        <div style="margin-top:14px; padding-top:14px; border-top:1px solid var(--color-border);">
          <b>${s.name}</b>
          <p>${s.description}</p>
          <a href="${s.link}" target="_blank">Learn more &rarr;</a>
        </div>
      `).join("")}
    `;
  } catch (err) {
    resultEl.innerHTML = "<p>Error checking schemes. Is the backend running?</p>";
    console.error(err);
  }
});
