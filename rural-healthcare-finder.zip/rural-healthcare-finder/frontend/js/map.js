let map;
let markers = [];

// Read query params passed from the Symptom Checker (recommended facility
// type + urgency level), so this page can filter/highlight accordingly.
const urlParams = new URLSearchParams(window.location.search);
const recommendedTypes = urlParams.get("type") ? urlParams.get("type").split(",") : null;
const urgencyLevel = urlParams.get("urgency");

function renderSymptomContextBanner() {
  const banner = document.getElementById("symptom-context-banner");
  if (!recommendedTypes) return;

  const urgencyLabel = urgencyLevel ? urgencyLevel.toUpperCase() : "";
  banner.innerHTML = `
    <div class="asha-card" style="margin-bottom:16px;">
      <h3>Based on your symptom check (${urgencyLabel})</h3>
      <p>Showing facilities suitable for your case: <b>${recommendedTypes.join(", ")}</b></p>
    </div>
  `;
}

function initMap(centerLat, centerLng) {
  map = L.map("map").setView([centerLat, centerLng], 11);
  L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
    attribution: "&copy; OpenStreetMap contributors",
  }).addTo(map);
}

function clearMarkers() {
  markers.forEach((m) => map.removeLayer(m));
  markers = [];
}

function filterByRecommendedType(facilities) {
  if (!recommendedTypes) return facilities;
  const filtered = facilities.filter((f) => recommendedTypes.includes(f.type));
  // If filtering leaves nothing (small sample data), fall back to showing all
  return filtered.length > 0 ? filtered : facilities;
}

function renderFacilities(facilities, centerLat, centerLng, centerLabel = "You are here") {
  clearMarkers();
  facilities = filterByRecommendedType(facilities);

  const centerMarker = L.marker([centerLat, centerLng]).addTo(map).bindPopup(centerLabel);
  markers.push(centerMarker);

  const listEl = document.getElementById("facility-list");
  listEl.innerHTML = "";

  facilities.forEach((f) => {
    const marker = L.marker([f.lat, f.lng]).addTo(map).bindPopup(`<b>${f.name}</b><br>${f.type}`);
    markers.push(marker);

    const doctorBadge = f.has_doctor === "Yes"
      ? `<span style="color: var(--color-minor); font-weight:600;">✅ Doctor available</span>`
      : `<span style="color: var(--color-urgent); font-weight:600;">⚠️ No doctor on-site — call ahead</span>`;

    const li = document.createElement("li");
    li.innerHTML = `
      <div class="fac-name">${f.name} (${f.type})</div>
      <div class="fac-meta">📍 ${f.distance_km} km away &middot; 📞 ${f.phone}</div>
      <div class="fac-meta">${doctorBadge}</div>
    `;
    listEl.appendChild(li);
  });
}

document.getElementById("locate-btn").addEventListener("click", () => {
  const statusEl = document.getElementById("status-msg");
  statusEl.textContent = "Getting your location...";

  if (!navigator.geolocation) {
    statusEl.textContent = "Geolocation not supported. Showing sample location instead.";
    loadFacilities(12.5242, 76.8958); // fallback: Mandya city
    return;
  }

  navigator.geolocation.getCurrentPosition(
    (pos) => {
      statusEl.textContent = "Location found.";
      loadFacilities(pos.coords.latitude, pos.coords.longitude);
    },
    () => {
      statusEl.textContent = "Location access denied. Showing sample location instead.";
      loadFacilities(12.5242, 76.8958); // fallback: Mandya city
    }
  );
});

async function loadFacilities(lat, lng) {
  if (!map) initMap(lat, lng);
  else map.setView([lat, lng], 11);

  try {
    const data = await fetchNearbyFacilities(lat, lng);
    renderFacilities(data.facilities, lat, lng);
  } catch (err) {
    document.getElementById("status-msg").textContent = "Error loading facilities. Is the backend running?";
    console.error(err);
  }
}

// ===== Search by typed location name =====
async function geocodeLocation(placeName) {
  const url = `https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(placeName)}&limit=1`;
  const res = await fetch(url, { headers: { "Accept-Language": "en" } });
  if (!res.ok) throw new Error("Geocoding request failed");
  const results = await res.json();
  if (results.length === 0) return null;
  return { lat: parseFloat(results[0].lat), lng: parseFloat(results[0].lon), label: results[0].display_name };
}

async function renderAshaCard(query) {
  const ashaContainer = document.getElementById("asha-card");
  ashaContainer.innerHTML = "";

  try {
    const result = await findAshaWorker(query);
    if (result.found) {
      const worker = result.workers[0];
      ashaContainer.innerHTML = `
        <div class="asha-card">
          <h3>👩‍⚕️ Your Local ASHA Worker</h3>
          <p>ASHA (Accredited Social Health Activist) workers are your village-level first point of contact for health guidance, maternal care, and connecting you to the right facility.</p>
          <div class="asha-contact">${worker.name} — ${worker.village} &middot; 📞 <a href="tel:${worker.phone}">${worker.phone}</a></div>
        </div>
      `;
    }
  } catch (err) {
    console.error("ASHA worker lookup failed", err);
  }
}

async function handleLocationSearch() {
  const statusEl = document.getElementById("status-msg");
  const input = document.getElementById("location-input");
  const placeName = input.value.trim();

  if (!placeName) {
    statusEl.textContent = "Please type a location name first.";
    return;
  }

  statusEl.textContent = `Searching for "${placeName}"...`;
  document.getElementById("asha-card").innerHTML = "";

  try {
    const localResult = await searchFacilitiesByName(placeName);
    if (localResult.found) {
      if (!map) initMap(localResult.center.lat, localResult.center.lng);
      else map.setView([localResult.center.lat, localResult.center.lng], 11);
      renderFacilities(
        localResult.facilities,
        localResult.center.lat,
        localResult.center.lng,
        `Matched: ${localResult.center.matched_name}`
      );
      statusEl.textContent = `Showing results near "${localResult.center.matched_name}"`;
      renderAshaCard(placeName);
      return;
    }
  } catch (err) {
    console.error("Local search failed, will try external geocoding", err);
  }

  try {
    const location = await geocodeLocation(placeName);
    if (!location) {
      statusEl.textContent = `Couldn't find "${placeName}". Try a nearby town or taluk name.`;
      return;
    }
    statusEl.textContent = `Showing results near ${location.label}`;
    loadFacilities(location.lat, location.lng);
    renderAshaCard(placeName);
  } catch (err) {
    statusEl.textContent = "Search failed. Check your internet connection and try again.";
    console.error(err);
  }
}

document.getElementById("search-btn").addEventListener("click", handleLocationSearch);
document.getElementById("location-input").addEventListener("keydown", (e) => {
  if (e.key === "Enter") handleLocationSearch();
});

renderSymptomContextBanner();
initMap(12.5242, 76.8958);
