// Include this on every page that requires login. Redirects to login.html
// immediately if no user is signed in.
(function () {
  const user = getCurrentUser();
  if (!user) {
    const currentPage = window.location.pathname.split("/").pop() || "index.html";
    window.location.href = `login.html?next=${encodeURIComponent(currentPage)}`;
  }
})();
