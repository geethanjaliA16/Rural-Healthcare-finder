// Keep this list in sync with backend/routes/triage.py keyword sets
const ALL_SYMPTOMS = [
  "fever", "persistent cough", "vomiting", "diarrhea", "body ache",
  "chest pain", "difficulty breathing", "severe bleeding", "severe abdominal pain",
  "mild headache", "common cold", "sore throat", "skin rash", "dizziness"
];

const optionsContainer = document.getElementById("symptom-options");
ALL_SYMPTOMS.forEach((symptom) => {
  const label = document.createElement("label");
  label.innerHTML = `<input type="checkbox" name="symptom" value="${symptom}"> ${symptom}`;
  optionsContainer.appendChild(label);
});

document.getElementById("triage-form").addEventListener("submit", async (e) => {
  e.preventDefault();
  await runTriageCheck();
});

async function runTriageCheck() {
  const checked = Array.from(document.querySelectorAll('input[name="symptom"]:checked'));
  const symptoms = checked.map((c) => c.value);

  // Include free-typed symptom, if the user entered one
  const otherInput = document.getElementById("other-symptom");
  const otherText = otherInput.value.trim();
  if (otherText) symptoms.push(otherText);

  const resultEl = document.getElementById("triage-result");

  if (symptoms.length === 0) {
    resultEl.classList.remove("hidden");
    resultEl.innerHTML = "<p>Please select or type at least one symptom.</p>";
    return;
  }

  resultEl.classList.remove("hidden");
  resultEl.innerHTML = "<p>Checking...</p>";

  try {
    const data = await checkTriage(symptoms);
    resultEl.className = `result-card urgency-${data.urgency}`;

    let emergencyHtml = "";
    if (data.emergency_number) {
      emergencyHtml = `
        <div class="emergency-banner">
          🚨 Call <a href="tel:${data.emergency_number}">${data.emergency_number}</a> now — India's free ambulance service
        </div>
      `;
    }

    // Carry urgency + recommended facility type into the Facility Finder page
    const typeParam = encodeURIComponent(data.recommend_facility_type.join(","));
    const findFacilityUrl = `facility-finder.html?type=${typeParam}&urgency=${data.urgency}`;

    resultEl.innerHTML = `
      <h3>Urgency: ${data.urgency.toUpperCase()}</h3>
      ${emergencyHtml}
      <p>${data.advice}</p>
      <p><b>Suggested facility type:</b> ${data.recommend_facility_type.join(", ")}</p>
      <a href="${findFacilityUrl}" class="btn" style="display:inline-block; margin-top:14px; text-decoration:none;">
        Find Nearest Suitable Facility &rarr;
      </a>
    `;
  } catch (err) {
    resultEl.innerHTML = "<p>Error checking symptoms. Is the backend running?</p>";
    console.error(err);
  }
}

// ===== Voice input for symptoms =====
const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;

if (SpeechRecognition) {
  const micBtn = document.getElementById("mic-btn");
  const voiceStatus = document.getElementById("voice-status");

  micBtn.addEventListener("click", () => {
    const recognition = new SpeechRecognition();
    recognition.lang = "en-IN";
    recognition.interimResults = false;

    voiceStatus.textContent = "🎙️ Listening... speak your symptoms now";
    micBtn.disabled = true;

    recognition.start();

    recognition.onresult = (event) => {
      const transcript = event.results[0][0].transcript.toLowerCase();
      voiceStatus.textContent = `Heard: "${transcript}"`;

      let matchedAny = false;
      ALL_SYMPTOMS.forEach((symptom) => {
        if (transcript.includes(symptom)) {
          const checkbox = document.querySelector(`input[value="${symptom}"]`);
          if (checkbox) {
            checkbox.checked = true;
            matchedAny = true;
          }
        }
      });

      // If nothing from our known list matched, drop the whole transcript
      // into the free-text box so the backend's fuzzy matching can try.
      if (!matchedAny) {
        document.getElementById("other-symptom").value = transcript;
        voiceStatus.textContent += " — added as typed symptom below.";
      }
    };

    recognition.onerror = (event) => {
      voiceStatus.textContent = `Voice input error: ${event.error}. Please select or type symptoms manually.`;
    };

    recognition.onend = () => {
      micBtn.disabled = false;
    };
  });
} else {
  const micBtn = document.getElementById("mic-btn");
  if (micBtn) micBtn.style.display = "none";
}
