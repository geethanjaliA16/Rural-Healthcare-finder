// Simple phone-number based login, stored in the browser (no backend auth server
// needed for a hackathon demo - this identifies the user across the session).
const CURRENT_USER_KEY = "gramcare_user";

function getCurrentUser() {
  const raw = localStorage.getItem(CURRENT_USER_KEY);
  return raw ? JSON.parse(raw) : null;
}

function setCurrentUser(user) {
  localStorage.setItem(CURRENT_USER_KEY, JSON.stringify(user));
}

function logoutUser() {
  localStorage.removeItem(CURRENT_USER_KEY);
  window.location.href = "index.html";
}

// Call at the top of a page that requires login. Redirects to login.html if
// no user is stored, carrying the current page so login can send them back.
function requireLogin() {
  const user = getCurrentUser();
  if (!user) {
    const currentPage = window.location.pathname.split("/").pop();
    window.location.href = `login.html?next=${encodeURIComponent(currentPage)}`;
    return null;
  }
  return user;
}

// Call on every page load to show login status in the navbar.
function renderNavUserStatus() {
  const el = document.getElementById("nav-user-status");
  if (!el) return;
  const user = getCurrentUser();
  if (user) {
    el.innerHTML = `<span class="nav-user">👤 ${user.name}</span> <a href="#" id="logout-link">Logout</a>`;
    const logoutLink = document.getElementById("logout-link");
    if (logoutLink) logoutLink.addEventListener("click", (e) => { e.preventDefault(); logoutUser(); });
  } else {
    el.innerHTML = `<a href="login.html">Login</a>`;
  }
}

document.addEventListener("DOMContentLoaded", renderNavUserStatus);
