from flask import Blueprint, request, jsonify
import csv
import os
import math

facilities_bp = Blueprint("facilities", __name__)

DATA_PATH = os.path.join(os.path.dirname(__file__), "..", "data", "facilities.csv")


def load_facilities():
    facilities = []
    with open(DATA_PATH, newline="", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        for row in reader:
            row["lat"] = float(row["lat"])
            row["lng"] = float(row["lng"])
            facilities.append(row)
    return facilities


def haversine_distance_km(lat1, lng1, lat2, lng2):
    # Standard great-circle distance formula - good enough for "nearest facility" ranking
    R = 6371  # Earth radius in km
    phi1, phi2 = math.radians(lat1), math.radians(lat2)
    d_phi = math.radians(lat2 - lat1)
    d_lambda = math.radians(lng2 - lng1)
    a = math.sin(d_phi / 2) ** 2 + math.cos(phi1) * math.cos(phi2) * math.sin(d_lambda / 2) ** 2
    return R * 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))


@facilities_bp.route("/facilities", methods=["GET"])
def get_nearby_facilities():
    lat = request.args.get("lat", type=float)
    lng = request.args.get("lng", type=float)

    facilities = load_facilities()

    if lat is None or lng is None:
        # No location given - just return all facilities (useful for map overview / testing)
        return jsonify({"facilities": facilities})

    for facility in facilities:
        facility["distance_km"] = round(
            haversine_distance_km(lat, lng, facility["lat"], facility["lng"]), 2
        )

    facilities.sort(key=lambda f: f["distance_km"])

    return jsonify({"facilities": facilities[:10]})  # top 10 nearest


@facilities_bp.route("/facilities/search", methods=["GET"])
def search_facilities_by_name():
    """
    Search our own facility data directly by name, type, or district text.
    This is more reliable than external geocoding for small villages/taluks
    that OpenStreetMap's Nominatim service may not recognize.
    """
    query = request.args.get("q", "").strip().lower()

    if not query:
        return jsonify({"error": "Please provide a search term"}), 400

    facilities = load_facilities()

    # Normalize by removing all spaces so variations like "bg nagar",
    # "b g nagar", and "bgnagar" all correctly match "B G Nagara".
    def normalize(text):
        return text.lower().replace(" ", "")

    query_norm = normalize(query)

    matches = [
        f for f in facilities
        if query in f["name"].lower() or query in f["district"].lower()
        or query_norm in normalize(f["name"]) or query_norm in normalize(f["district"])
    ]

    if not matches:
        return jsonify({"facilities": [], "found": False})

    # Use the first match's coordinates as the "center point" for this search,
    # and return all matches plus other nearby facilities for context.
    center = matches[0]
    for f in facilities:
        f["distance_km"] = round(
            haversine_distance_km(center["lat"], center["lng"], f["lat"], f["lng"]), 2
        )
    facilities.sort(key=lambda f: f["distance_km"])

    return jsonify({
        "facilities": facilities[:10],
        "found": True,
        "center": {"lat": center["lat"], "lng": center["lng"], "matched_name": center["name"]}
    })
