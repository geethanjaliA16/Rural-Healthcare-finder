from flask import Blueprint, request, jsonify
import csv
import os

schemes_bp = Blueprint("schemes", __name__)

DATA_PATH = os.path.join(os.path.dirname(__file__), "..", "data", "schemes.csv")


def load_schemes():
    schemes = []
    with open(DATA_PATH, newline="", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        for row in reader:
            row["max_income"] = int(row["max_income"])
            schemes.append(row)
    return schemes


@schemes_bp.route("/schemes", methods=["POST"])
def check_eligible_schemes():
    data = request.get_json(force=True)
    state = data.get("state", "").strip().lower()

    try:
        income = int(data.get("income", 0))
    except (TypeError, ValueError):
        return jsonify({"error": "income must be a number"}), 400

    schemes = load_schemes()
    eligible = []

    for scheme in schemes:
        income_ok = income <= scheme["max_income"]
        state_ok = scheme["states"].strip().lower() == "all" or scheme["states"].strip().lower() == state
        if income_ok and state_ok:
            eligible.append(scheme)

    return jsonify({"eligible_schemes": eligible, "count": len(eligible)})
