from flask import Blueprint, request, jsonify

triage_bp = Blueprint("triage", __name__)

# IMPORTANT: this is a simple RULE-BASED guidance tool, not a medical diagnosis system.
# Keep language framed as "what kind of care to seek", never "you have X condition".

URGENT_SYMPTOMS = {
    "chest pain", "difficulty breathing", "severe bleeding", "unconsciousness",
    "high fever with stiff neck", "severe abdominal pain", "seizure",
    "signs of stroke", "snake bite", "severe burns"
}

MODERATE_SYMPTOMS = {
    "fever", "persistent cough", "vomiting", "diarrhea", "body ache",
    "mild breathing difficulty", "skin rash", "moderate pain", "dizziness",
    "ear ache", "joint pain", "stomach pain", "back pain"
}

MINOR_SYMPTOMS = {
    "mild headache", "common cold", "minor cuts", "mild fatigue",
    "sore throat", "mild allergy"
}


def matches_any(user_symptoms, keyword_set):
    """
    Checks whether any user-provided symptom (from checkboxes OR free-typed
    text) matches a known keyword - using substring matching in both
    directions, so free text like "I have high fever today" still matches
    "fever", and typed "cold" matches "common cold".
    """
    for s in user_symptoms:
        for keyword in keyword_set:
            if keyword in s or s in keyword:
                return True
    return False


@triage_bp.route("/triage", methods=["POST"])
def triage_check():
    data = request.get_json(force=True)
    symptoms = [s.strip().lower() for s in data.get("symptoms", []) if s.strip()]

    if not symptoms:
        return jsonify({"error": "Please provide at least one symptom"}), 400

    if matches_any(symptoms, URGENT_SYMPTOMS):
        return jsonify({
            "urgency": "urgent",
            "advice": "These symptoms need immediate attention. Please go to the nearest "
                      "hospital or PHC right away, or call emergency services.",
            "recommend_facility_type": ["Hospital", "CHC", "Taluk Hospital", "District Hospital"],
            "emergency_number": "108"
        })

    if matches_any(symptoms, MODERATE_SYMPTOMS):
        return jsonify({
            "urgency": "moderate",
            "advice": "It's a good idea to see a doctor soon. You can visit a nearby PHC, "
                      "or consider a telemedicine consultation if travel is difficult.",
            "recommend_facility_type": ["PHC", "CHC"]
        })

    if matches_any(symptoms, MINOR_SYMPTOMS):
        return jsonify({
            "urgency": "minor",
            "advice": "This looks manageable with home care and rest. If symptoms persist "
                      "beyond 2-3 days or worsen, please visit a PHC.",
            "recommend_facility_type": ["PHC", "Sub Centre"]
        })

    # Fallback for symptoms not in our simple keyword lists (mostly free-typed text)
    return jsonify({
        "urgency": "unknown",
        "advice": "We couldn't confidently assess these symptoms. When in doubt, it's "
                  "safest to consult a healthcare worker at your nearest PHC.",
        "recommend_facility_type": ["PHC"]
    })
