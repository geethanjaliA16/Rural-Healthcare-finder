from flask import Blueprint, request, jsonify
import csv
import os

asha_bp = Blueprint("asha", __name__)

DATA_PATH = os.path.join(os.path.dirname(__file__), "..", "data", "asha_workers.csv")


def load_asha_workers():
    workers = []
    with open(DATA_PATH, newline="", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        for row in reader:
            workers.append(row)
    return workers


@asha_bp.route("/asha-worker", methods=["GET"])
def find_asha_worker():
    """
    Find the local ASHA (Accredited Social Health Activist) worker for a
    given village or taluk name. ASHA workers are India's real village-level
    community health worker system - first point of contact for many
    rural households, especially for maternal/child health.
    """
    query = request.args.get("q", "").strip().lower()

    if not query:
        return jsonify({"error": "Please provide a village or taluk name"}), 400

    workers = load_asha_workers()
    matches = [
        w for w in workers
        if query in w["village"].lower() or query in w["taluk"].lower()
    ]

    return jsonify({"workers": matches, "found": len(matches) > 0})
