from flask import Flask, jsonify, send_from_directory
from flask_cors import CORS
import os

from routes.facilities import facilities_bp
from routes.triage import triage_bp
from routes.schemes import schemes_bp
from routes.asha import asha_bp

app = Flask(__name__)
CORS(app)  # allow frontend (served separately or via file://) to call the API

# Register route blueprints
app.register_blueprint(facilities_bp, url_prefix="/api")
app.register_blueprint(triage_bp, url_prefix="/api")
app.register_blueprint(schemes_bp, url_prefix="/api")
app.register_blueprint(asha_bp, url_prefix="/api")


@app.route("/")
def health_check():
    return jsonify({"status": "ok", "message": "Rural Healthcare Access Finder API running"})


if __name__ == "__main__":
    # debug=True gives auto-reload during dev; turn off for the actual demo if it misbehaves
    app.run(debug=True, port=5000)
